﻿/*
* Copyright 2010-2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
*
* Licensed under the Apache License, Version 2.0 (the "License").
* You may not use this file except in compliance with the License.
* A copy of the License is located at
*
*  http://aws.amazon.com/apache2.0
*
* or in the "license" file accompanying this file. This file is distributed
* on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
* express or implied. See the License for the specific language governing
* permissions and limitations under the License.
*/

#pragma once
#include <aws/storagegateway/StorageGateway_EXPORTS.h>
#include <aws/storagegateway/StorageGatewayRequest.h>
#include <aws/core/utils/memory/stl/AWSString.h>
#include <aws/storagegateway/model/ObjectACL.h>
#include <aws/core/utils/memory/stl/AWSVector.h>
#include <utility>

namespace Aws
{
namespace StorageGateway
{
namespace Model
{

  /**
   * <p>UpdateSMBFileShareInput</p><p><h3>See Also:</h3>   <a
   * href="http://docs.aws.amazon.com/goto/WebAPI/storagegateway-2013-06-30/UpdateSMBFileShareInput">AWS
   * API Reference</a></p>
   */
  class AWS_STORAGEGATEWAY_API UpdateSMBFileShareRequest : public StorageGatewayRequest
  {
  public:
    UpdateSMBFileShareRequest();
    
    // Service request name is the Operation name which will send this request out,
    // each operation should has unique request name, so that we can get operation's name from this request.
    // Note: this is not true for response, multiple operations may have the same response name,
    // so we can not get operation's name from response.
    inline virtual const char* GetServiceRequestName() const override { return "UpdateSMBFileShare"; }

    Aws::String SerializePayload() const override;

    Aws::Http::HeaderValueCollection GetRequestSpecificHeaders() const override;


    /**
     * <p>The Amazon Resource Name (ARN) of the SMB file share you want to update.</p>
     */
    inline const Aws::String& GetFileShareARN() const{ return m_fileShareARN; }

    /**
     * <p>The Amazon Resource Name (ARN) of the SMB file share you want to update.</p>
     */
    inline void SetFileShareARN(const Aws::String& value) { m_fileShareARNHasBeenSet = true; m_fileShareARN = value; }

    /**
     * <p>The Amazon Resource Name (ARN) of the SMB file share you want to update.</p>
     */
    inline void SetFileShareARN(Aws::String&& value) { m_fileShareARNHasBeenSet = true; m_fileShareARN = std::move(value); }

    /**
     * <p>The Amazon Resource Name (ARN) of the SMB file share you want to update.</p>
     */
    inline void SetFileShareARN(const char* value) { m_fileShareARNHasBeenSet = true; m_fileShareARN.assign(value); }

    /**
     * <p>The Amazon Resource Name (ARN) of the SMB file share you want to update.</p>
     */
    inline UpdateSMBFileShareRequest& WithFileShareARN(const Aws::String& value) { SetFileShareARN(value); return *this;}

    /**
     * <p>The Amazon Resource Name (ARN) of the SMB file share you want to update.</p>
     */
    inline UpdateSMBFileShareRequest& WithFileShareARN(Aws::String&& value) { SetFileShareARN(std::move(value)); return *this;}

    /**
     * <p>The Amazon Resource Name (ARN) of the SMB file share you want to update.</p>
     */
    inline UpdateSMBFileShareRequest& WithFileShareARN(const char* value) { SetFileShareARN(value); return *this;}


    /**
     * <p>True to use Amazon S3 server side encryption with your own AWS KMS key, or
     * false to use a key managed by Amazon S3. Optional.</p>
     */
    inline bool GetKMSEncrypted() const{ return m_kMSEncrypted; }

    /**
     * <p>True to use Amazon S3 server side encryption with your own AWS KMS key, or
     * false to use a key managed by Amazon S3. Optional.</p>
     */
    inline void SetKMSEncrypted(bool value) { m_kMSEncryptedHasBeenSet = true; m_kMSEncrypted = value; }

    /**
     * <p>True to use Amazon S3 server side encryption with your own AWS KMS key, or
     * false to use a key managed by Amazon S3. Optional.</p>
     */
    inline UpdateSMBFileShareRequest& WithKMSEncrypted(bool value) { SetKMSEncrypted(value); return *this;}


    /**
     * <p>The Amazon Resource Name (ARN) KMS key used for Amazon S3 server side
     * encryption. This value can only be set when KMSEncrypted is true. Optional.</p>
     */
    inline const Aws::String& GetKMSKey() const{ return m_kMSKey; }

    /**
     * <p>The Amazon Resource Name (ARN) KMS key used for Amazon S3 server side
     * encryption. This value can only be set when KMSEncrypted is true. Optional.</p>
     */
    inline void SetKMSKey(const Aws::String& value) { m_kMSKeyHasBeenSet = true; m_kMSKey = value; }

    /**
     * <p>The Amazon Resource Name (ARN) KMS key used for Amazon S3 server side
     * encryption. This value can only be set when KMSEncrypted is true. Optional.</p>
     */
    inline void SetKMSKey(Aws::String&& value) { m_kMSKeyHasBeenSet = true; m_kMSKey = std::move(value); }

    /**
     * <p>The Amazon Resource Name (ARN) KMS key used for Amazon S3 server side
     * encryption. This value can only be set when KMSEncrypted is true. Optional.</p>
     */
    inline void SetKMSKey(const char* value) { m_kMSKeyHasBeenSet = true; m_kMSKey.assign(value); }

    /**
     * <p>The Amazon Resource Name (ARN) KMS key used for Amazon S3 server side
     * encryption. This value can only be set when KMSEncrypted is true. Optional.</p>
     */
    inline UpdateSMBFileShareRequest& WithKMSKey(const Aws::String& value) { SetKMSKey(value); return *this;}

    /**
     * <p>The Amazon Resource Name (ARN) KMS key used for Amazon S3 server side
     * encryption. This value can only be set when KMSEncrypted is true. Optional.</p>
     */
    inline UpdateSMBFileShareRequest& WithKMSKey(Aws::String&& value) { SetKMSKey(std::move(value)); return *this;}

    /**
     * <p>The Amazon Resource Name (ARN) KMS key used for Amazon S3 server side
     * encryption. This value can only be set when KMSEncrypted is true. Optional.</p>
     */
    inline UpdateSMBFileShareRequest& WithKMSKey(const char* value) { SetKMSKey(value); return *this;}


    /**
     * <p>The default storage class for objects put into an Amazon S3 bucket by file
     * gateway. Possible values are S3_STANDARD, S3_STANDARD_IA or S3_ONEZONE_IA. If
     * this field is not populated, the default value S3_STANDARD is used.
     * Optional.</p>
     */
    inline const Aws::String& GetDefaultStorageClass() const{ return m_defaultStorageClass; }

    /**
     * <p>The default storage class for objects put into an Amazon S3 bucket by file
     * gateway. Possible values are S3_STANDARD, S3_STANDARD_IA or S3_ONEZONE_IA. If
     * this field is not populated, the default value S3_STANDARD is used.
     * Optional.</p>
     */
    inline void SetDefaultStorageClass(const Aws::String& value) { m_defaultStorageClassHasBeenSet = true; m_defaultStorageClass = value; }

    /**
     * <p>The default storage class for objects put into an Amazon S3 bucket by file
     * gateway. Possible values are S3_STANDARD, S3_STANDARD_IA or S3_ONEZONE_IA. If
     * this field is not populated, the default value S3_STANDARD is used.
     * Optional.</p>
     */
    inline void SetDefaultStorageClass(Aws::String&& value) { m_defaultStorageClassHasBeenSet = true; m_defaultStorageClass = std::move(value); }

    /**
     * <p>The default storage class for objects put into an Amazon S3 bucket by file
     * gateway. Possible values are S3_STANDARD, S3_STANDARD_IA or S3_ONEZONE_IA. If
     * this field is not populated, the default value S3_STANDARD is used.
     * Optional.</p>
     */
    inline void SetDefaultStorageClass(const char* value) { m_defaultStorageClassHasBeenSet = true; m_defaultStorageClass.assign(value); }

    /**
     * <p>The default storage class for objects put into an Amazon S3 bucket by file
     * gateway. Possible values are S3_STANDARD, S3_STANDARD_IA or S3_ONEZONE_IA. If
     * this field is not populated, the default value S3_STANDARD is used.
     * Optional.</p>
     */
    inline UpdateSMBFileShareRequest& WithDefaultStorageClass(const Aws::String& value) { SetDefaultStorageClass(value); return *this;}

    /**
     * <p>The default storage class for objects put into an Amazon S3 bucket by file
     * gateway. Possible values are S3_STANDARD, S3_STANDARD_IA or S3_ONEZONE_IA. If
     * this field is not populated, the default value S3_STANDARD is used.
     * Optional.</p>
     */
    inline UpdateSMBFileShareRequest& WithDefaultStorageClass(Aws::String&& value) { SetDefaultStorageClass(std::move(value)); return *this;}

    /**
     * <p>The default storage class for objects put into an Amazon S3 bucket by file
     * gateway. Possible values are S3_STANDARD, S3_STANDARD_IA or S3_ONEZONE_IA. If
     * this field is not populated, the default value S3_STANDARD is used.
     * Optional.</p>
     */
    inline UpdateSMBFileShareRequest& WithDefaultStorageClass(const char* value) { SetDefaultStorageClass(value); return *this;}


    /**
     * <p>Sets the access control list permission for objects in the Amazon S3 bucket
     * that a file gateway puts objects into. The default value is "private".</p>
     */
    inline const ObjectACL& GetObjectACL() const{ return m_objectACL; }

    /**
     * <p>Sets the access control list permission for objects in the Amazon S3 bucket
     * that a file gateway puts objects into. The default value is "private".</p>
     */
    inline void SetObjectACL(const ObjectACL& value) { m_objectACLHasBeenSet = true; m_objectACL = value; }

    /**
     * <p>Sets the access control list permission for objects in the Amazon S3 bucket
     * that a file gateway puts objects into. The default value is "private".</p>
     */
    inline void SetObjectACL(ObjectACL&& value) { m_objectACLHasBeenSet = true; m_objectACL = std::move(value); }

    /**
     * <p>Sets the access control list permission for objects in the Amazon S3 bucket
     * that a file gateway puts objects into. The default value is "private".</p>
     */
    inline UpdateSMBFileShareRequest& WithObjectACL(const ObjectACL& value) { SetObjectACL(value); return *this;}

    /**
     * <p>Sets the access control list permission for objects in the Amazon S3 bucket
     * that a file gateway puts objects into. The default value is "private".</p>
     */
    inline UpdateSMBFileShareRequest& WithObjectACL(ObjectACL&& value) { SetObjectACL(std::move(value)); return *this;}


    /**
     * <p>Sets the write status of a file share. This value is true if the write status
     * is read-only, and otherwise false.</p>
     */
    inline bool GetReadOnly() const{ return m_readOnly; }

    /**
     * <p>Sets the write status of a file share. This value is true if the write status
     * is read-only, and otherwise false.</p>
     */
    inline void SetReadOnly(bool value) { m_readOnlyHasBeenSet = true; m_readOnly = value; }

    /**
     * <p>Sets the write status of a file share. This value is true if the write status
     * is read-only, and otherwise false.</p>
     */
    inline UpdateSMBFileShareRequest& WithReadOnly(bool value) { SetReadOnly(value); return *this;}


    /**
     * <p>Enables guessing of the MIME type for uploaded objects based on file
     * extensions. Set this value to true to enable MIME type guessing, and otherwise
     * to false. The default value is true.</p>
     */
    inline bool GetGuessMIMETypeEnabled() const{ return m_guessMIMETypeEnabled; }

    /**
     * <p>Enables guessing of the MIME type for uploaded objects based on file
     * extensions. Set this value to true to enable MIME type guessing, and otherwise
     * to false. The default value is true.</p>
     */
    inline void SetGuessMIMETypeEnabled(bool value) { m_guessMIMETypeEnabledHasBeenSet = true; m_guessMIMETypeEnabled = value; }

    /**
     * <p>Enables guessing of the MIME type for uploaded objects based on file
     * extensions. Set this value to true to enable MIME type guessing, and otherwise
     * to false. The default value is true.</p>
     */
    inline UpdateSMBFileShareRequest& WithGuessMIMETypeEnabled(bool value) { SetGuessMIMETypeEnabled(value); return *this;}


    /**
     * <p>Sets who pays the cost of the request and the data download from the Amazon
     * S3 bucket. Set this value to true if you want the requester to pay instead of
     * the bucket owner, and otherwise to false.</p>
     */
    inline bool GetRequesterPays() const{ return m_requesterPays; }

    /**
     * <p>Sets who pays the cost of the request and the data download from the Amazon
     * S3 bucket. Set this value to true if you want the requester to pay instead of
     * the bucket owner, and otherwise to false.</p>
     */
    inline void SetRequesterPays(bool value) { m_requesterPaysHasBeenSet = true; m_requesterPays = value; }

    /**
     * <p>Sets who pays the cost of the request and the data download from the Amazon
     * S3 bucket. Set this value to true if you want the requester to pay instead of
     * the bucket owner, and otherwise to false.</p>
     */
    inline UpdateSMBFileShareRequest& WithRequesterPays(bool value) { SetRequesterPays(value); return *this;}


    /**
     * <p>A list of users in the Active Directory that are allowed to access the file
     * share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline const Aws::Vector<Aws::String>& GetValidUserList() const{ return m_validUserList; }

    /**
     * <p>A list of users in the Active Directory that are allowed to access the file
     * share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline void SetValidUserList(const Aws::Vector<Aws::String>& value) { m_validUserListHasBeenSet = true; m_validUserList = value; }

    /**
     * <p>A list of users in the Active Directory that are allowed to access the file
     * share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline void SetValidUserList(Aws::Vector<Aws::String>&& value) { m_validUserListHasBeenSet = true; m_validUserList = std::move(value); }

    /**
     * <p>A list of users in the Active Directory that are allowed to access the file
     * share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline UpdateSMBFileShareRequest& WithValidUserList(const Aws::Vector<Aws::String>& value) { SetValidUserList(value); return *this;}

    /**
     * <p>A list of users in the Active Directory that are allowed to access the file
     * share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline UpdateSMBFileShareRequest& WithValidUserList(Aws::Vector<Aws::String>&& value) { SetValidUserList(std::move(value)); return *this;}

    /**
     * <p>A list of users in the Active Directory that are allowed to access the file
     * share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline UpdateSMBFileShareRequest& AddValidUserList(const Aws::String& value) { m_validUserListHasBeenSet = true; m_validUserList.push_back(value); return *this; }

    /**
     * <p>A list of users in the Active Directory that are allowed to access the file
     * share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline UpdateSMBFileShareRequest& AddValidUserList(Aws::String&& value) { m_validUserListHasBeenSet = true; m_validUserList.push_back(std::move(value)); return *this; }

    /**
     * <p>A list of users in the Active Directory that are allowed to access the file
     * share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline UpdateSMBFileShareRequest& AddValidUserList(const char* value) { m_validUserListHasBeenSet = true; m_validUserList.push_back(value); return *this; }


    /**
     * <p>A list of users in the Active Directory that are not allowed to access the
     * file share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline const Aws::Vector<Aws::String>& GetInvalidUserList() const{ return m_invalidUserList; }

    /**
     * <p>A list of users in the Active Directory that are not allowed to access the
     * file share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline void SetInvalidUserList(const Aws::Vector<Aws::String>& value) { m_invalidUserListHasBeenSet = true; m_invalidUserList = value; }

    /**
     * <p>A list of users in the Active Directory that are not allowed to access the
     * file share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline void SetInvalidUserList(Aws::Vector<Aws::String>&& value) { m_invalidUserListHasBeenSet = true; m_invalidUserList = std::move(value); }

    /**
     * <p>A list of users in the Active Directory that are not allowed to access the
     * file share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline UpdateSMBFileShareRequest& WithInvalidUserList(const Aws::Vector<Aws::String>& value) { SetInvalidUserList(value); return *this;}

    /**
     * <p>A list of users in the Active Directory that are not allowed to access the
     * file share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline UpdateSMBFileShareRequest& WithInvalidUserList(Aws::Vector<Aws::String>&& value) { SetInvalidUserList(std::move(value)); return *this;}

    /**
     * <p>A list of users in the Active Directory that are not allowed to access the
     * file share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline UpdateSMBFileShareRequest& AddInvalidUserList(const Aws::String& value) { m_invalidUserListHasBeenSet = true; m_invalidUserList.push_back(value); return *this; }

    /**
     * <p>A list of users in the Active Directory that are not allowed to access the
     * file share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline UpdateSMBFileShareRequest& AddInvalidUserList(Aws::String&& value) { m_invalidUserListHasBeenSet = true; m_invalidUserList.push_back(std::move(value)); return *this; }

    /**
     * <p>A list of users in the Active Directory that are not allowed to access the
     * file share. Can only be set if Authentication is set to "ActiveDirectory".</p>
     */
    inline UpdateSMBFileShareRequest& AddInvalidUserList(const char* value) { m_invalidUserListHasBeenSet = true; m_invalidUserList.push_back(value); return *this; }

  private:

    Aws::String m_fileShareARN;
    bool m_fileShareARNHasBeenSet;

    bool m_kMSEncrypted;
    bool m_kMSEncryptedHasBeenSet;

    Aws::String m_kMSKey;
    bool m_kMSKeyHasBeenSet;

    Aws::String m_defaultStorageClass;
    bool m_defaultStorageClassHasBeenSet;

    ObjectACL m_objectACL;
    bool m_objectACLHasBeenSet;

    bool m_readOnly;
    bool m_readOnlyHasBeenSet;

    bool m_guessMIMETypeEnabled;
    bool m_guessMIMETypeEnabledHasBeenSet;

    bool m_requesterPays;
    bool m_requesterPaysHasBeenSet;

    Aws::Vector<Aws::String> m_validUserList;
    bool m_validUserListHasBeenSet;

    Aws::Vector<Aws::String> m_invalidUserList;
    bool m_invalidUserListHasBeenSet;
  };

} // namespace Model
} // namespace StorageGateway
} // namespace Aws
